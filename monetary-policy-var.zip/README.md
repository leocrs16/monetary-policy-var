# Monetary Policy Transmission in Brazil and the United States
## A Comparative VAR Analysis of the 2021–2024 Tightening Cycle

[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)](https://www.python.org/)
[![Jupyter](https://img.shields.io/badge/Jupyter-Notebook-orange)](https://jupyter.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## Overview

This repository contains the full replication code and data pipeline for a comparative
VAR (Vector Autoregression) analysis of monetary policy transmission in **Brazil** and
the **United States** during the 2021–2024 monetary tightening cycle — the most
aggressive synchronized tightening episode in decades.

The analysis estimates separate VAR models for each country, generates
**Impulse Response Functions (IRFs)** and **Forecast Error Variance Decompositions (FEVD)**,
and compares transmission mechanisms across two structurally distinct economies:
an inflation-targeting emerging market (Brazil) and the world's reserve currency issuer (USA).

---

## Research Questions

1. How does the **speed and magnitude** of monetary policy transmission to inflation differ
   between Brazil and the United States?
2. What is the role of the **exchange rate channel** in each country's inflation dynamics?
3. What does variance decomposition reveal about **fiscal/exchange rate dominance**
   versus monetary policy in driving inflation in each economy?

---

## Key Variables

| Country | Interest Rate | Inflation | Exchange Rate | Source |
|---------|--------------|-----------|---------------|--------|
| Brazil  | Selic Rate   | IPCA      | BRL/USD       | SGS/BCB |
| USA     | Fed Funds Rate | CPI     | DXY Index     | FRED |

**Sample period:** January 2021 – December 2024 (48 monthly observations)

---

## Repository Structure

```
monetary-policy-var/
│
├── data/
│   ├── raw/                  # Original downloaded series (never modified)
│   └── processed/            # Cleaned, transformed, analysis-ready data
│
├── notebooks/
│   ├── 01_data_collection.ipynb      # SGS (BCB) + FRED API calls
│   ├── 02_exploratory_analysis.ipynb # Descriptive stats, time series plots
│   ├── 03_stationarity_tests.ipynb   # ADF and KPSS tests
│   ├── 04_var_brazil.ipynb           # VAR estimation — Brazil
│   ├── 05_var_usa.ipynb              # VAR estimation — USA
│   └── 06_comparative_analysis.ipynb # IRF + FEVD comparison
│
├── src/
│   ├── data_collection.py    # Functions for BCB/FRED API
│   ├── preprocessing.py      # Transformations and stationarity utils
│   ├── var_estimation.py     # VAR fitting, diagnostics, IRF, FEVD
│   └── visualization.py      # Publication-ready plots
│
├── outputs/
│   ├── figures/              # All charts (.png / .pdf)
│   └── tables/               # LaTeX/CSV tables for the paper
│
├── docs/
│   └── variable_definitions.md   # Detailed variable metadata
│
├── requirements.txt
├── .gitignore
└── README.md
```

---

## Methodology

### Models

Each country is modeled with a trivariate VAR:

- **Brazil:** `[Selic, BRL/USD (log), IPCA]`
- **USA:** `[Fed Funds Rate, DXY (log), CPI inflation]`

### Identification

Structural shocks are identified via **Cholesky decomposition**, with the following
recursive ordering (based on economic theory):

```
Interest Rate → Exchange Rate → Inflation
```

*Rationale:* The central bank sets the policy rate first; the exchange rate responds
to interest rate differentials within the same period; inflation adjusts with a lag
due to price stickiness.

### Estimation Steps

1. **Unit root tests** — ADF (H₀: unit root) and KPSS (H₀: stationarity), applied
   to levels and first differences
2. **Lag selection** — AIC, BIC, and HQIC criteria
3. **VAR(p) estimation** — OLS equation-by-equation
4. **Diagnostic tests** — Portmanteau (autocorrelation), Jarque-Bera (normality),
   characteristic root stability
5. **IRF** — Orthogonalized, with 95% bootstrap confidence bands (1,000 replications),
   12-month horizon
6. **FEVD** — Forecast Error Variance Decomposition at 1, 3, 6, and 12 months

---

## Getting Started

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/monetary-policy-var.git
cd monetary-policy-var
```

### 2. Create and activate a virtual environment

```bash
python -m venv venv
source venv/bin/activate        # macOS/Linux
venv\Scripts\activate           # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Set up your FRED API key

Get a free key at [fred.stlouisfed.org/docs/api/api_key.html](https://fred.stlouisfed.org/docs/api/api_key.html)

```bash
# Create a .env file in the project root (never commit this file)
echo "FRED_API_KEY=your_key_here" > .env
```

### 5. Run the notebooks in order

```bash
jupyter lab
```

Open `notebooks/01_data_collection.ipynb` and run sequentially.

> **Note:** The SGS/BCB API does not require authentication.
> Only the FRED API key is needed.

---

## Main Results (Preview)

> *Full results, tables and figures are generated by running the notebooks.*

| Metric | Brazil | USA |
|--------|--------|-----|
| Lag order selected (BIC) | TBD | TBD |
| Peak IRF response of inflation to rate shock | TBD | TBD |
| Months to peak response | TBD | TBD |
| Share of inflation variance explained by rate (12m) | TBD | TBD |

---

## Dependencies

See `requirements.txt` for the full list. Core packages:

| Package | Purpose |
|---------|---------|
| `pandas` | Data manipulation |
| `requests` | BCB/SGS API calls |
| `fredapi` | FRED API wrapper |
| `statsmodels` | VAR estimation, ADF/KPSS |
| `arch` | KPSS and additional unit root tests |
| `matplotlib` / `seaborn` | Visualization |
| `python-dotenv` | API key management |

---

## Data Sources

- **Banco Central do Brasil — SGS:** [https://www.bcb.gov.br/estatisticas/tabelaespecial](https://www.bcb.gov.br/estatisticas/tabelaespecial)
- **Federal Reserve Bank of St. Louis — FRED:** [https://fred.stlouisfed.org](https://fred.stlouisfed.org)

---

## Citation

If you use this code or replicate the analysis, please cite:

```
[Author], (2025). Monetary Policy Transmission in Brazil and the United States:
A Comparative VAR Analysis of the 2021–2024 Tightening Cycle.
Undergraduate Research Paper, UFRGS — Department of Economics.
GitHub: https://github.com/YOUR_USERNAME/monetary-policy-var
```

---

## License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.

---

## Author

**[Your Name]**
Undergraduate student in Economics — UFRGS
Research interests: Applied Econometrics, Time Series, Monetary Policy
