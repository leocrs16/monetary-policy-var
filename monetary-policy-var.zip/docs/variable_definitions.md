# Variable Definitions and Metadata

## Brazil

| Variable | Description | Source | Series Code | Freq. | Transformation |
|----------|-------------|--------|-------------|-------|----------------|
| `selic`  | Selic overnight rate (target), % p.a. | SGS/BCB | 432 | Monthly | Levels |
| `ipca`   | IPCA — broad consumer price index, monthly % change | SGS/BCB | 433 | Monthly | Already in % change |
| `brl_usd`| BRL/USD — commercial exchange rate (sell), end of period | SGS/BCB | 3698 | Monthly | Log levels; Δlog for stationarity |

## United States

| Variable | Description | Source | Series Code | Freq. | Transformation |
|----------|-------------|--------|-------------|-------|----------------|
| `fedfunds` | Effective Federal Funds Rate, % p.a. | FRED | `FEDFUNDS` | Monthly | Levels |
| `cpi`      | CPI All Urban Consumers, monthly % change (computed from index) | FRED | `CPIAUCSL` | Monthly | % change (log diff × 100) |
| `dxy`      | Nominal Broad Dollar Index (DXY equivalent) | FRED | `DTWEXBGS` | Monthly | Log levels; Δlog for stationarity |

## Sample Period

- **Start:** January 2021
- **End:** December 2024
- **Observations:** 48 monthly data points per series

## Notes on Transformations

- Exchange rates enter the VAR in **log first differences** (i.e., monthly % appreciation/depreciation)
  after unit root tests confirm a unit root in log levels.
- Interest rates are kept in **levels** if the ADF/KPSS tests support stationarity,
  or in first differences otherwise. Given the tightening cycle, both series are
  arguably trend-stationary within the sample — this is discussed in Section 5 of the paper.
- CPI is already expressed as monthly % change; no additional transformation needed
  beyond the seasonal adjustment inherited from BLS (USA) or IBGE (Brazil).

## Key Event Timeline

| Date | Brazil | USA |
|------|--------|-----|
| Jan 2021 | Selic at 2.00% (historic low) | Fed Funds at 0.00–0.25% |
| Mar 2021 | BCB begins tightening (+0.75 pp) | — |
| Mar 2022 | — | Fed begins tightening (+0.25 pp) |
| Aug 2022 | Selic peaks at 13.75% | — |
| Jul 2023 | — | Fed Funds peaks at 5.25–5.50% |
| Jun 2023 | BCB begins easing cycle | — |
| Sep 2024 | — | Fed begins easing cycle |
| Dec 2024 | Selic back at ~12.25% | Fed Funds at ~4.50% |
